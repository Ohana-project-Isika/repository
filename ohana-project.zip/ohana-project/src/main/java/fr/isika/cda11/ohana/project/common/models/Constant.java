package fr.isika.cda11.ohana.project.common.models;

public class Constant {
    public static final String ACCOUNT_ATTRIBUTE = "loggedInUser";
    public static final String ACCOUNT_CONNECTED = "connected";
}
