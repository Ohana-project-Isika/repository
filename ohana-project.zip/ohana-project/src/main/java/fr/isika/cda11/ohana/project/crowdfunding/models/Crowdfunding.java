package fr.isika.cda11.ohana.project.crowdfunding.models;

public class Crowdfunding {

}
