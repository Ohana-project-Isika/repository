package fr.isika.cda11.ohana.project.enumclass;

public enum EnumRole {

	//selon DC UML
	PRIVATEPERSON, ADMIN, ASSOCIATION
	
}
