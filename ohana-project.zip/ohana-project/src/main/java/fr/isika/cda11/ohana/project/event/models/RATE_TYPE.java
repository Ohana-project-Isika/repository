package fr.isika.cda11.ohana.project.event.models;

/**
 * Created on 11/11/2021
 * @author manu
 */
public enum RATE_TYPE {
    REDUCED1, REDUCED2, REGULAR, SUPER_REDUCED
}
