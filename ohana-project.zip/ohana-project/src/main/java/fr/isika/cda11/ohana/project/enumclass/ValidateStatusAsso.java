package fr.isika.cda11.ohana.project.enumclass;

public enum ValidateStatusAsso {
	VALIDATED, INPROCESS, REJECTED
}
