package fr.isika.cda11.ohana.project.enumclass;

public enum Subscription {
	OK
}
